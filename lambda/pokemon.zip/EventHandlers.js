var AlexaAssets = require("./AlexaAssets");

var registerEventHandlers = function (eventHandlers) {

	eventHandlers.onSessionStarted = function (sessionStartedReqeust, session, response) {
		// session started logic
        response.ask(
            AlexaAssets.Welcome.speechOutput+" "+AlexaAssets.PlayerCount.speechOutput,
            AlexaAssets.PlayerCount.repromptOutput
        );
	};

	eventHandlers.onLaunch = function (launchRequest, session, response) {
    console.log("ONLAUNCH");
        response.ask(
            AlexaAssets.Welcome.speechOutput+" "+AlexaAssets.PlayerCount.speechOutput,
            AlexaAssets.PlayerCount.repromptOutput
        );
	};

	eventHandlers.onSessionEnded = function (sessionEndedRequest, session) {
		// session ended cleanup
	};
};

module.exports.register = registerEventHandlers;
